from django.urls import reverse
from django.views.generic import CreateView, UpdateView, DeleteView
from django.shortcuts import get_object_or_404, redirect

from tenaga_kediklatan.models import TenagaKediklatan, TipeTenagaKediklatan
from tenaga_kediklatan.forms.tenaga import TenagaKediklatanForm, TenagaKediklatanUpdateForm
from lppbj.models import Lppbj


# Create your views here.
class TenagaCreate(CreateView):
    model = TenagaKediklatan
    template_name = 'form.html'

    form_class = TenagaKediklatanForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lppbj = get_object_or_404(Lppbj, pk=self.kwargs['id_lppbj'])
        tipe_tenaga = get_object_or_404(TipeTenagaKediklatan, 
                                        pk=self.kwargs['id_tipe_tenaga'])

        context['title'] = 'Tambah %s LPPBJ %s' % (tipe_tenaga.nama.title(), lppbj.singkatan)

        return context

    def form_valid(self, form):
        lppbj = get_object_or_404(Lppbj, pk=self.kwargs['id_lppbj'])
        tenaga = get_object_or_404(TipeTenagaKediklatan, pk=self.kwargs['id_tipe_tenaga'])
        data = {
            'lppbj': lppbj,
            'tipe_tenaga': tenaga
        }
        form.save(data)
        
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.kwargs['id_lppbj'],))


class TenagaUpdate(UpdateView):
    model = TenagaKediklatan
    template_name = 'form.html'

    form_class = TenagaKediklatanUpdateForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lppbj = context['tenagakediklatan'].lppbj
        tipe_tenaga = context['tenagakediklatan'].tipe

        context['title'] = 'Update %s LPPBJ %s' % (tipe_tenaga.nama.title(), lppbj.singkatan)

        return context

    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.object.lppbj.pk,))


class TenagaDelete(DeleteView):
    model = TenagaKediklatan
    
    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.object.lppbj.pk,))
