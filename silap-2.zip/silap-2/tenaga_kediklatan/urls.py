from django.urls import path
from tenaga_kediklatan.views import TenagaCreate, TenagaUpdate, TenagaDelete

urlpatterns = [
    path('add/<int:id_lppbj>/<int:id_tipe_tenaga>', TenagaCreate.as_view(), name='tenaga-kediklatan-create'),
    path('edit/<int:pk>', TenagaUpdate.as_view(), name='tenaga-kediklatan-update'),
    path('delete/<int:pk>', TenagaDelete.as_view(), name='tenaga-kediklatan-delete'),
]