from django.apps import AppConfig


class TenagaKediklatanConfig(AppConfig):
    name = 'tenaga_kediklatan'
