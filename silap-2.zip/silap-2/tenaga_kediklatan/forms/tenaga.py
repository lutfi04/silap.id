from tenaga_kediklatan.models import TenagaKediklatan, TipeTenagaKediklatan
from lppbj.models import Lppbj
from django import forms


class TenagaKediklatanForm(forms.ModelForm):
    nama = forms.CharField(widget=forms.Textarea(attrs={
        'rows': 2,
        'class': 'form-control'
    }))
    telepon = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Masukkan nomor telepon jika tipe tenaga kediklatan adalah Pimpinan/Admin/MOT'
    }), required=False)
    email = forms.EmailField(widget=forms.EmailInput(attrs={
        'class': 'form-control',
        'placeholder': 'Masukkan nomor telepon jika tipe tenaga kediklatan adalah Admin/MOT'
    }), required=False)
    jabatan = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Masukkan nomor telepon jika tipe tenaga kediklatan adalah Pimpinan'
    }), required=False)

    class Meta:
        model = TenagaKediklatan
        exclude = ('lppbj', 'tipe')

    def save(self, data):
        obj = super(TenagaKediklatanForm, self).save(commit=False)
        obj.lppbj = data['lppbj']
        obj.tipe = data['tipe_tenaga']

        obj.save()

        return obj


class TenagaKediklatanUpdateForm(TenagaKediklatanForm):
    class Meta:
        model = TenagaKediklatan
        exclude = ('lppbj', 'tipe')

    def save(self):
        obj = super(TenagaKediklatanForm, self).save()
        obj.save()

        return obj
