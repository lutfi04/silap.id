from django.db import models
from lppbj.models import Lppbj


class TipeTenagaKediklatan(models.Model):
    nama = models.CharField(max_length=100)

    def __str__(self):
        return self.nama


class TenagaKediklatan(models.Model):
    nama = models.TextField()
    telepon = models.CharField(max_length=30, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    jabatan = models.CharField(max_length=100, blank=True, null=True)
    lppbj = models.ForeignKey(Lppbj, on_delete=models.CASCADE, blank=True, null=True)
    tipe = models.ForeignKey(TipeTenagaKediklatan, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return "%s %s" % (self.nama, self.jabatan)
