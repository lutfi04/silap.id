from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import TipeTenagaKediklatan, TenagaKediklatan


admin.site.register(TipeTenagaKediklatan)

@admin.register(TenagaKediklatan)
class TenagaKediklatanAdmin(ImportExportModelAdmin):
    pass
