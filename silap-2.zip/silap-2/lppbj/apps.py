from django.apps import AppConfig


class LppbjConfig(AppConfig):
    name = 'lppbj'
