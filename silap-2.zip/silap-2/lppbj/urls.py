from django.urls import path
from lppbj.views.lppbj import LppbjCreate, LppbjDelete, LppbjDetail,\
                        LppbjList, LppbjUpdate
from lppbj.views.laporan import MasaBerlakuLPPBJ,\
                                PelatihanLPPBJTerdaftar,\
                                MonevLPPBJ, ResumeLPPBJ, LPPBJByAkreditasi,\
                                LPPBJByJenis, LPPBJByKasus, LPPBJByProvinsi,\
                                LPPBJByKlasifikasi

urlpatterns = [
    path('view-all/', LppbjList.as_view(), name='lppbj-list'),
    path('add/', LppbjCreate.as_view(), name='lppbj-create'),
    path('edit/<int:pk>/', LppbjUpdate.as_view(), name='lppbj-update'),
    path('delete/<int:pk>/', LppbjDelete.as_view(), name='lppbj-delete'),
    path('view/<int:pk>/', LppbjDetail.as_view(), name='lppbj-detail'),

    path('laporan/masa-berlaku/', MasaBerlakuLPPBJ.as_view(),
         name='laporan-masa-berlaku-lppbj'),
    path('laporan/pelatihan-lppbj-terdaftar/',
         PelatihanLPPBJTerdaftar.as_view(),
         name='laporan-pelatihan-lppbj-terdaftar'),
    path('laporan/monev/', MonevLPPBJ.as_view(), name='laporan-monev-lppbj'),
    path('laporan/resume/', ResumeLPPBJ.as_view(),
         name='laporan-resume-lppbj'),
    
    path('laporan/by-akreditasi/', LPPBJByAkreditasi.as_view(),
         name='laporan-lppbj-by-akreditasi'),
    path('laporan/by-jenis/', LPPBJByJenis.as_view(),
         name='laporan-lppbj-by-jenis'),
    path('laporan/by-kasus/', LPPBJByKasus.as_view(),
         name='laporan-lppbj-by-kasus'),
    path('laporan/by-klasifikasi/', LPPBJByKlasifikasi.as_view(),
         name='laporan-lppbj-by-klasifikasi'),
    path('laporan/by-provinsi/', LPPBJByProvinsi.as_view(),
         name='laporan-lppbj-by-provinsi'),
]