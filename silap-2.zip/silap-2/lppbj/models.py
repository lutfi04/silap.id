from django.db import models
from django.urls import reverse


class JenisLppbj(models.Model):
    nama = models.CharField(max_length=200)

    def __str__(self):
        return self.nama


class KlasifikasiLppbj(models.Model):
    nama = models.CharField(max_length=300)

    def __str__(self):
        return self.nama


class Lppbj(models.Model):
    nama = models.TextField()
    singkatan = models.TextField()
    email = models.EmailField()
    situs_web = models.CharField(max_length=200, blank=True, null=True)
    telepon_kantor = models.CharField(max_length=30, blank=True, null=True)
    nomor_hp = models.CharField(max_length=30, blank=True, null=True)
    jenis_lppbj = models.ForeignKey(JenisLppbj, on_delete=models.CASCADE)
    klasifikasi_lppbj = models.ForeignKey(KlasifikasiLppbj,
                                          on_delete=models.CASCADE,
                                          blank=True, null=True)

    def __str__(self):
        return self.nama

    def get_absolute_url(self):
        return reverse('lppbj-detail', kwargs={'pk': self.pk})


class AlamatLppbj(models.Model):
    lppbj = models.OneToOneField(Lppbj, on_delete=models.CASCADE)
    alamat = models.TextField()
    kota_kab = models.CharField(max_length=200)
    provinsi = models.CharField(max_length=200)
    kode_pos = models.CharField(max_length=10, blank=True, null=True)

    def __str__(self):
        return "%s %s %s" % (self.alamat, self.kota_kab, self.provinsi)
