from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import Lppbj, JenisLppbj, KlasifikasiLppbj, AlamatLppbj


admin.site.register(KlasifikasiLppbj)
admin.site.register(JenisLppbj)


@admin.register(Lppbj)
class LppbjAdmin(ImportExportModelAdmin):
    pass


@admin.register(AlamatLppbj)
class AlamatLppbjAdmin(ImportExportModelAdmin):
    pass
