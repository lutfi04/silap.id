import re
import datetime

from django.views.generic import ListView, TemplateView
from lppbj.models import Lppbj, KlasifikasiLppbj, JenisLppbj
from akreditasi.models import AkreditasiLppbj, Monev,\
                              TipeAkreditasi, TingkatMonev, Pelatihan,\
                              TingkatMonev
from .lppbj import generate_akreditasi_now


class MasaBerlakuLPPBJ(ListView):
    model = Lppbj
    template_name = 'lppbj/laporan/masa-berlaku-lppbj.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_masa_berlaku_lppbj(self, context)
        context['range_masa_berlaku'] = self.request.GET['hari']
        context['title'] = 'Laporan Berdasarkan Masa Berlaku Akreditasi LPPBJ'

        return context


class PelatihanLPPBJTerdaftar(ListView):
    model = Lppbj
    template_name = 'lppbj/laporan/pelatihan-lppbj-terdaftar.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_pelatihan_lppbj_terdaftar(context)
        context['title'] = 'Laporan Berdasarkan Jumlah Pelatihan LPPBJ ' + \
                           ' Terdaftar'

        return context


class ResumeLPPBJ(TemplateView):
    template_name = 'lppbj/resume.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        count_lppbj_by_akreditasi(context)
        count_lppbj_by_klasifikasi(context)
        count_lppbj_by_jenis(context)
        count_lppbj_by_kasus(context)
        context['title'] = 'Resume LPPBJ'

        return context


class LPPBJByAkreditasi(TemplateView):
    template_name = 'lppbj/laporan/lppbj-by-akreditasi.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        group_lppbj_by_akreditasi(context)

        context['title'] = 'Laporan LPPBJ Berdasarkan Akreditasi'
        return context


class LPPBJByJenis(TemplateView):
    template_name = 'lppbj/laporan/lppbj-by-jenis.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        group_lppbj_by_jenis(context)

        context['title'] = 'Laporan LPPBJ Berdasarkan Jenis'
        return context


class LPPBJByKasus(TemplateView):
    template_name = 'lppbj/laporan/lppbj-by-kasus.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        group_lppbj_by_kasus(context)
        context['title'] = 'Laporan LPPBJ Berdasarkan Kasus'

        return context


class LPPBJByKlasifikasi(TemplateView):
    template_name = 'lppbj/laporan/lppbj-by-klasifikasi.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        group_lppbj_by_klasifikasi(context)
        context['title'] = 'Laporan LPPBJ Berdasarkan Klasifikasi'

        return context


class LPPBJByProvinsi(ListView):
    model = Lppbj
    template_name = 'lppbj/laporan/lppbj-by-provinsi.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Laporan LPPBJ Berdasarkan Provinsi'

        return context


class MonevLPPBJ(ListView):
    model = Lppbj
    template_name = 'lppbj/laporan/monev-lppbj.html'
    queryset = Lppbj.objects.all().order_by('nama')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_monev_lppbj(context)
        context['title'] = 'Laporan Berdasarkan Monev'

        return context


def group_lppbj_by_akreditasi(context):
    tipe_akreditasi_list = TipeAkreditasi.objects.all()
    context['lppbj_list'] = {}
    for tipe_akreditasi in tipe_akreditasi_list:
        dict_key = string_to_dict_key(tipe_akreditasi.tipe)
        context['lppbj_list'][dict_key] = Lppbj.objects.filter(
            akreditasilppbj__tipe_akreditasi=tipe_akreditasi,
            akreditasilppbj__aktif=True
        )


def group_lppbj_by_jenis(context):
    jenis_lppbj_list = JenisLppbj.objects.all()
    context['lppbj_list'] = {}
    for jenis_lppbj in jenis_lppbj_list:
        dict_key = string_to_dict_key(jenis_lppbj.nama)
        context['lppbj_list'][dict_key] = Lppbj.objects.filter(
            jenis_lppbj=jenis_lppbj
        )

    for val in context['lppbj_list'].values():
        generate_akreditasi_now(val)


def group_lppbj_by_klasifikasi(context):
    klasifikasi_lppbj_list = KlasifikasiLppbj.objects.all()
    context['lppbj_list'] = {}
    for klasifikasi_lppbj in klasifikasi_lppbj_list:
        dict_key = string_to_dict_key(klasifikasi_lppbj.nama)
        context['lppbj_list'][dict_key] = Lppbj.objects.filter(
            klasifikasi_lppbj=klasifikasi_lppbj
        )

    for val in context['lppbj_list'].values():
        generate_akreditasi_now(val)


def group_lppbj_by_kasus(context):
    kasus_lppbj_list = TingkatMonev.objects.all()
    context['lppbj_list'] = {}
    for kasus_lppbj in kasus_lppbj_list:
        dict_key = string_to_dict_key(kasus_lppbj.nama)
        context['lppbj_list'][dict_key] = Lppbj.objects.filter(
            akreditasilppbj__monev__tingkat_monev=kasus_lppbj
        )

    for val in context['lppbj_list'].values():
        generate_akreditasi_now(val)


def string_to_dict_key(s):
    return re.sub('[^0-9a-zA-Z]+', '_', s).lower()


def count_filter(context, context_name, obj_model, **kwargs):
    object_list = obj_model.objects.all()
    context[context_name] = {}
    for obj in object_list:
        count_tipe = Lppbj.objects.filter(kwargs).count()

        dict_key = string_to_dict_key(tipe_akreditasi.tipe)
        context[context_name][dict_key] = count_tipe


def count_lppbj_by_akreditasi(context):
    tipe_akreditasi_list = TipeAkreditasi.objects.all()
    context['akreditasi'] = {}
    for tipe_akreditasi in tipe_akreditasi_list:
        count_tipe = Lppbj.objects.filter(
            akreditasilppbj__tipe_akreditasi=tipe_akreditasi,
            akreditasilppbj__aktif=True).count()

        dict_key = string_to_dict_key(tipe_akreditasi.tipe)
        context['akreditasi'][dict_key] = count_tipe


def count_lppbj_by_klasifikasi(context):
    klasifikasi_lppbj_list = KlasifikasiLppbj.objects.all()
    context['klasifikasi'] = {}
    for klasifikasi_lppbj in klasifikasi_lppbj_list:
        count_tipe = Lppbj.objects.filter(
            klasifikasi_lppbj=klasifikasi_lppbj).count()

        dict_key = string_to_dict_key(klasifikasi_lppbj.nama)
        context['klasifikasi'][dict_key] = count_tipe


def count_lppbj_by_jenis(context):
    jenis_lppbj_list = JenisLppbj.objects.all()
    context['jenis'] = {}
    for jenis_lppbj in jenis_lppbj_list:
        count_tipe = Lppbj.objects.filter(jenis_lppbj=jenis_lppbj).count()

        dict_key = string_to_dict_key(jenis_lppbj.nama)
        context['jenis'][dict_key] = count_tipe


def count_lppbj_by_kasus(context):
    tingkat_monev_list = TingkatMonev.objects.all()
    context['tingkat'] = {}
    for tingkat_monev in tingkat_monev_list:
        count_tipe = Lppbj.objects.filter(
                akreditasilppbj__aktif=True,
                akreditasilppbj__monev__tingkat_monev=tingkat_monev
            ).count()

        dict_key = string_to_dict_key(tingkat_monev.nama)
        context['tingkat'][dict_key] = count_tipe


def filter_monev_lppbj(context):
    for lppbj in context['lppbj_list']:
        akreditasilppbj = AkreditasiLppbj.objects.filter(
                          lppbj=lppbj, aktif=True).first()
        lppbj.monev = Monev.objects.filter(
                akreditasi_lppbj=akreditasilppbj,
                akreditasi_lppbj__aktif=True
            ).last()


def filter_masa_berlaku_lppbj(self, context):
    startdate = datetime.date(1990, 1, 1)
    enddate = datetime.date.today(
    ) + datetime.timedelta(days=int(self.request.GET['hari']))

    masa_berlaku_lppbj_list = Lppbj.objects.filter(
                                akreditasilppbj__aktif=True,
                                akreditasilppbj__tanggal_expired__range=[
                                    startdate, enddate
                                ]
                              )

    masa_berlaku_lppbj_list = masa_berlaku_lppbj_list.order_by(
        'akreditasilppbj__tanggal_expired')
    for lppbj in masa_berlaku_lppbj_list:
        lppbj.tanggal_expired = AkreditasiLppbj.objects.filter(
            aktif=True, lppbj=lppbj).first().tanggal_expired

    context['masa_berlaku_lppbj_list'] = masa_berlaku_lppbj_list


def filter_kasus_lppbj(context):
    akreditasi_aktif_lppbj_list = Lppbj.objects.filter(
                                    akreditasilppbj__aktif=True
                                  )

    prev_lppbj = None
    for lppbj in akreditasi_aktif_lppbj_list:
        if prev_lppbj is not None and prev_lppbj.id == lppbj.id:
            akreditasi_aktif_lppbj_list.exclude(lppbj)
            prev_lppbj = None
        else:
            prev_lppbj = lppbj
            monev = Monev.objects.filter(akreditasi_lppbj__lppbj=lppbj,
                                         akreditasi_lppbj__aktif=True).last()
            if monev is not None:
                lppbj.tingkat_monev = monev.tingkat_monev
                lppbj.temuan_monev = monev.temuan
            else:
                lppbj.tingkat_monev = 'Belum terdapat kasus'

    context['kasus_lppbj_list'] = akreditasi_aktif_lppbj_list


def filter_pelatihan_lppbj_terdaftar(context):
    lppbj_terdaftar = Lppbj.objects.filter(
                        akreditasilppbj__aktif=True,
                        akreditasilppbj__tipe_akreditasi__tipe='Terdaftar'
                      )

    for lppbj in lppbj_terdaftar:
        jumlah_pelatihan_lppbj = Pelatihan.objects.filter(
                                    akreditasi_lppbj__lppbj=lppbj,
                                    akreditasi_lppbj__tipe_akreditasi__tipe='Terdaftar'
                                 ).count()
        lppbj.jumlah_pelatihan = jumlah_pelatihan_lppbj

    context['lppbj_terdaftar_list'] = lppbj_terdaftar
