from django.views.generic import DetailView, ListView, CreateView,\
    UpdateView, DeleteView, RedirectView
from django.urls import reverse_lazy, reverse
from django.views.generic import TemplateView
from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm

from lppbj.models import Lppbj, AlamatLppbj
from lppbj.forms.lppbj import LppbjForm, LppbjUpdateForm

from tenaga_kediklatan.models import TenagaKediklatan, TipeTenagaKediklatan
from akreditasi.models import AkreditasiLppbj, Monev, Pelatihan

import datetime


def home_page_view(request):
    return redirect('laporan-resume-lppbj')


def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Password anda telah berhasil diubah!')
            return redirect('ubah-password')
        else:
            messages.error(request, 'Tolong perbaiki error di bawah.')
    else:
        form = PasswordChangeForm(request.user)
    
    return render(request, 'ubah-password.html', {
        'form': form,
        'title': 'Ubah Password'
    })


class LppbjList(ListView):
    model = Lppbj
    template_name = 'lppbj/list.html'
    queryset = Lppbj.objects.all().order_by('nama')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'List LPPBJ'
        generate_akreditasi_now(context['lppbj_list'])

        return context


class LppbjDetail(DetailView):
    model = Lppbj
    template_name = 'lppbj/detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_tipe_tenaga(context)
        generate_context_tenaga_kediklatan(context)
        generate_context_akreditasi(context)
        context['title'] = 'Detail LPPBJ ' + context['lppbj'].singkatan

        return context


class LppbjCreate(CreateView):
    model = Lppbj
    template_name = 'lppbj/form.html'

    form_class = LppbjForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Tambah LPPBJ'

        return context

    def form_valid(self, form):
        alamat = form.cleaned_data['alamat']
        kota_kab = form.cleaned_data['kota_kab']
        provinsi = form.cleaned_data['provinsi']
        kode_pos = form.cleaned_data['kode_pos']

        lppbj = form.save()
        alamat_lppbj = AlamatLppbj.objects.create(
                        lppbj=lppbj,
                        alamat=alamat,
                        kota_kab=kota_kab,
                        provinsi=provinsi,
                        kode_pos=kode_pos)

        return super(LppbjCreate, self).form_valid(form)


class LppbjUpdate(UpdateView):
    model = Lppbj
    template_name = 'lppbj/form.html'

    form_class = LppbjUpdateForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Update LPPBJ ' + context['lppbj'].singkatan

        return context

    def get_form_kwargs(self):
        kwargs = super(LppbjUpdate, self).get_form_kwargs()
        kwargs['id_lppbj'] = self.kwargs['pk']
        return kwargs

    def form_valid(self, form):
        alamat = form.cleaned_data['alamat']
        kota_kab = form.cleaned_data['kota_kab']
        provinsi = form.cleaned_data['provinsi']
        kode_pos = form.cleaned_data['kode_pos']

        lppbj = form.save()
        alamat_lppbj = AlamatLppbj.objects.filter(lppbj=lppbj).update(
                        lppbj=lppbj,
                        alamat=alamat,
                        kota_kab=kota_kab,
                        provinsi=provinsi,
                        kode_pos=kode_pos)

        return super(LppbjUpdate, self).form_valid(form)


class LppbjDelete(DeleteView):
    model = Lppbj
    success_url = reverse_lazy('lppbj-list')


def generate_akreditasi_now(lppbj_list):
    for lppbj in lppbj_list:
        akreditasi_now = AkreditasiLppbj.objects.filter(lppbj=lppbj,\
                         aktif=True).first()
        
        if akreditasi_now:
            lppbj.tipe_akreditasi_now = akreditasi_now.tipe_akreditasi
        else:
            lppbj.tipe_akreditasi_now = None


def filter_or_none(filtered_model, isFirst, **kwargs):
    test = filtered_model.filter(kwargs)

    if test is not None:
        if isFirst:
            test = test.first()
    else:
        test = "-"

    return test


def filter_tipe_tenaga(context):
    all_tipe_tenaga = TipeTenagaKediklatan.objects.all()
    tipe_tenaga = {}

    for tipe in all_tipe_tenaga:
        tipe_tenaga[tipe.nama] = tipe.pk

    context['tipe_tenaga'] = tipe_tenaga


def generate_context_tenaga_kediklatan(context):
    tenaga_kediklatan = TenagaKediklatan.objects.filter(lppbj=context['lppbj'])

    context['pimpinan'] = tenaga_kediklatan.filter(
        tipe__nama='pimpinan').first()
    context['admin'] = tenaga_kediklatan.filter(tipe__nama='admin').first()
    context['mot'] = tenaga_kediklatan.filter(tipe__nama='mot').first()
    context['tocs'] = tenaga_kediklatan.filter(tipe__nama='toc')
    context['fasilitators'] = tenaga_kediklatan.filter(
        tipe__nama='fasilitator')
    context['analis'] = tenaga_kediklatan.filter(tipe__nama='analis').first()
    context['pengelola_si'] = tenaga_kediklatan.filter(
        tipe__nama='pengelola').first()


def generate_context_akreditasi(context):
    akreditasis = AkreditasiLppbj.objects.filter(lppbj=context['lppbj'])

    akreditasi_now = akreditasis.filter(aktif=True).first()
    context['akreditasi_lamas'] = akreditasis.filter(aktif=False)

    context['monev_terbaru'] = Monev.objects.filter(
                                    akreditasi_lppbj=akreditasi_now
                               ).last()

    context['akreditasi_now'] = akreditasi_now
