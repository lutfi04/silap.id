from import_export import resources
from .models import Lppbj


class LppbjResource(resources.ModelResource):
    class Meta:
        model = Lppbj
