from lppbj.models import Lppbj, JenisLppbj, KlasifikasiLppbj, AlamatLppbj
from django import forms
from django.shortcuts import get_object_or_404


class LppbjForm(forms.ModelForm):
    nama = forms.CharField(widget=forms.Textarea(attrs={
                    'rows': 2,
                    'class': 'form-control'
                }))
    singkatan = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control'
                }))
    email = forms.EmailField(widget=forms.EmailInput(attrs={
                    'class': 'form-control'
                }))
    situs_web = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control'
                }), required=False)
    telepon_kantor = forms.CharField(widget=forms.TextInput(attrs={
                        'class': 'form-control'
                     }), required=False)
    nomor_hp = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control'
                }), required=False)
    jenis_lppbj = forms.ModelChoiceField(widget=forms.Select(attrs={
                        'class': 'form-control'
                  }), queryset=JenisLppbj.objects.all(), label='Jenis LPPBJ')
    klasifikasi_lppbj = forms.ModelChoiceField(widget=forms.Select(attrs={
                            'class': 'form-control'
                        }), queryset=KlasifikasiLppbj.objects.all(),
                        label='Klasifikasi LPPBJ')
    alamat = forms.CharField(widget=forms.Textarea(attrs={
                    'rows': 4,
                    'class': 'form-control'
                }))
    kota_kab = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control',
                }), label='Kota/Kab')
    provinsi = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control'
                }))
    kode_pos = forms.CharField(widget=forms.TextInput(attrs={
                    'class': 'form-control'
                }), required=False)

    class Meta:
        model = Lppbj
        fields = '__all__'


class LppbjUpdateForm(LppbjForm):
    class Meta:
        model = Lppbj
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        id_lppbj = kwargs.pop('id_lppbj')

        alamat_lppbj = get_object_or_404(AlamatLppbj, lppbj__id=id_lppbj)

        super(LppbjForm, self).__init__(*args, **kwargs)

        self.fields['alamat'] = forms.CharField(widget=forms.Textarea(attrs={
                        'rows': 4,
                        'class': 'form-control'
                    }), initial=alamat_lppbj.alamat)
        self.fields['kota_kab'] = forms.CharField(widget=forms.TextInput(attrs={
                        'class': 'form-control',
                    }), initial=alamat_lppbj.kota_kab, label='Kota/Kab')
        self.fields['provinsi'] = forms.CharField(widget=forms.TextInput(attrs={
                        'class': 'form-control'
                    }), initial=alamat_lppbj.provinsi)
        self.fields['kode_pos'] = forms.CharField(widget=forms.TextInput(attrs={
                        'class': 'form-control'
                    }), initial=alamat_lppbj.kode_pos, required=False)
