from django.db import models
from lppbj.models import Lppbj
from django.core.validators import MaxValueValidator, MinValueValidator


class TipeAkreditasi(models.Model):
    tipe = models.CharField(max_length=200)
    lppbj = models.ManyToManyField(
        Lppbj,
        through='AkreditasiLppbj',
        through_fields=('tipe_akreditasi', 'lppbj'),
    )

    def __str__(self):
        return self.tipe


class AkreditasiLppbj(models.Model):
    lppbj = models.ForeignKey(Lppbj, on_delete=models.CASCADE)
    tipe_akreditasi = models.ForeignKey(TipeAkreditasi,
                                        on_delete=models.CASCADE)
    nomor_sk = models.TextField()
    link_sk = models.TextField(blank=True, null=True)
    tanggal_berlaku = models.DateField(blank=True, null=True)
    tanggal_expired = models.DateField(blank=True, null=True)
    aktif = models.BooleanField()

    def __str__(self):
        return "%s %s" % (self.lppbj, self.tipe_akreditasi)


class Pelatihan(models.Model):
    akreditasi_lppbj = models.ForeignKey(AkreditasiLppbj, on_delete=models.CASCADE)
    tanggal = models.DateField()

    def __str__(self):
        return "%s %s" % (self.akreditasi_lppbj, self.tanggal)


class TingkatMonev(models.Model):
    nama = models.CharField(max_length=100)

    def __str__(self):
        return self.nama


class Monev(models.Model):
    akreditasi_lppbj = models.ForeignKey(AkreditasiLppbj, 
                                         on_delete=models.CASCADE)
    tanggal = models.DateField()
    temuan = models.TextField()
    lokasi = models.TextField(blank=True, null=True)
    nilai_lppbj = models.DecimalField(max_digits=3, decimal_places=2,
                                      validators=[
                                          MinValueValidator(0),
                                          MaxValueValidator(1)
                                      ], blank=True, null=True)
    rekom_lppbj = models.TextField(blank=True, null=True)
    nilai_toc = models.DecimalField(max_digits=3, decimal_places=2,
                                    validators=[
                                        MinValueValidator(0),
                                        MaxValueValidator(1)
                                    ], blank=True, null=True)
    rekom_toc = models.TextField(blank=True, null=True)
    nilai_fasil = models.DecimalField(max_digits=3, decimal_places=2,
                                      validators=[
                                          MinValueValidator(0),
                                          MaxValueValidator(1)
                                      ], blank=True, null=True)
    rekom_fasil = models.TextField(blank=True, null=True)
    rekom_pusdiklat = models.TextField(blank=True, null=True)
    tingkat_monev = models.ForeignKey(TingkatMonev, on_delete=models.CASCADE,
                                      blank=True, null=True)

    def __str__(self):
        return "%s %s" % (self.akreditasi_lppbj, self.tanggal)
