from django.urls import path
from akreditasi.views import AkreditasiCreate, AkreditasiUpdate,\
                             AkreditasiDelete, MonevCreate, MonevUpdate,\
                             MonevDelete, PelatihanCreate, PelatihanUpdate,\
                             PelatihanDelete

urlpatterns = [
    path('add/<int:id_lppbj>/', AkreditasiCreate.as_view(), name='akreditasi-create'),
    path('edit/<int:pk>', AkreditasiUpdate.as_view(), name='akreditasi-update'),
    path('delete/<int:pk>', AkreditasiDelete.as_view(), name='akreditasi-delete'),
    
    path('add/pelatihan/<int:id_akreditasi>/', PelatihanCreate.as_view(), name='pelatihan-create'),
    path('edit/pelatihan/<int:pk>', PelatihanUpdate.as_view(), name='pelatihan-update'),
    path('delete/pelatihan/<int:pk>', PelatihanDelete.as_view(), name='pelatihan-delete'),

    path('add/monev/<int:id_akreditasi>', MonevCreate.as_view(), name='monev-create'),
    path('edit/monev/<int:pk>', MonevUpdate.as_view(), name='monev-update'),
    path('delete/monev/<int:pk>', MonevDelete.as_view(), name='monev-delete'),
]