from django.apps import AppConfig


class AkreditasiConfig(AppConfig):
    name = 'akreditasi'
