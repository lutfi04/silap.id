from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import TipeAkreditasi, AkreditasiLppbj, Pelatihan,\
                    TingkatMonev, Monev


admin.site.register(TipeAkreditasi)
admin.site.register(TingkatMonev)


@admin.register(AkreditasiLppbj)
class AkreditasiLppbjAdmin(ImportExportModelAdmin):
    pass


@admin.register(Pelatihan)
class PelatihanLppbjAdmin(ImportExportModelAdmin):
    pass


@admin.register(Monev)
class MonevLppbjAdmin(ImportExportModelAdmin):
    pass
