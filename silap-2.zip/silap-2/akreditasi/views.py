from django.urls import reverse
from django.views.generic import CreateView, UpdateView, DeleteView
from django.shortcuts import get_object_or_404, redirect

from akreditasi.models import AkreditasiLppbj, Monev, Pelatihan
from akreditasi.forms.akreditasi import AkreditasiForm, AkreditasiUpdateForm
from akreditasi.forms.pelatihan import PelatihanForm, PelatihanUpdateForm
from akreditasi.forms.monev import MonevForm, MonevUpdateForm
from lppbj.models import Lppbj


class AkreditasiCreate(CreateView):
    model = AkreditasiLppbj
    template_name = 'form.html'

    form_class = AkreditasiForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lppbj = get_object_or_404(Lppbj, pk=self.kwargs['id_lppbj'])

        context['title'] = 'Tambah Akreditasi LPPBJ %s' % (lppbj.singkatan)

        return context

    def form_valid(self, form):
        lppbj = get_object_or_404(Lppbj, pk=self.kwargs['id_lppbj'])
        data = {
            'lppbj': lppbj,
        }

        is_aktif = form.cleaned_data['aktif']
        if is_aktif:
            akreditasi_lppbjs = AkreditasiLppbj.objects.filter(lppbj=lppbj).update(aktif=False)

        form.save(data)

        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.kwargs['id_lppbj'],))


class AkreditasiUpdate(UpdateView):
    model = AkreditasiLppbj
    template_name = 'form.html'

    form_class = AkreditasiUpdateForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        akreditasi = context['akreditasilppbj']
        lppbj = akreditasi.lppbj

        context['title'] = 'Update Akreditasi LPPBJ %s' % (lppbj.singkatan)

        return context

    def form_valid(self, form):
        akreditasi = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['pk'])
        lppbj = get_object_or_404(Lppbj, pk=akreditasi.lppbj.pk)

        is_aktif = form.cleaned_data['aktif']
        if is_aktif:
            akreditasi_lppbjs = AkreditasiLppbj.objects.filter(lppbj=lppbj).update(aktif=False)

        form.save()

        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.object.lppbj.pk,))


class AkreditasiDelete(DeleteView):
    model = AkreditasiLppbj
    
    def get_success_url(self):
        return reverse('lppbj-detail', args=(self.object.lppbj.pk,))


class MonevCreate(CreateView):
    model = Monev
    template_name = 'form.html'

    form_class = MonevForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        lppbj = akreditasi_lppbj.lppbj

        context['title'] = 'Tambah Monev LPPBJ %s' % (lppbj.singkatan)

        return context

    def form_valid(self, form):
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        data = {
            'akreditasi_lppbj': akreditasi_lppbj,
        }

        form.save(data)

        return redirect(self.get_success_url())

    def get_success_url(self):
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        return reverse('lppbj-detail', args=(akreditasi_lppbj.lppbj.pk,))


class MonevUpdate(UpdateView):
    model = Monev
    template_name = 'form.html'

    form_class = MonevUpdateForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        monev = context['monev']
        lppbj = monev.akreditasi_lppbj.lppbj

        context['title'] = 'Update Monev LPPBJ %s' % (lppbj.singkatan)

        return context

    def get_success_url(self):
        monev = get_object_or_404(Monev, pk=self.kwargs['pk'])
        return reverse('lppbj-detail', args=(monev.akreditasi_lppbj.lppbj.pk,))


class MonevDelete(DeleteView):
    model = Monev
    
    def get_success_url(self):
        monev = get_object_or_404(Monev, pk=self.kwargs['pk'])
        return reverse('lppbj-detail', args=(monev.akreditasi_lppbj.lppbj.pk,))


class PelatihanCreate(CreateView):
    model = Pelatihan
    template_name = 'form.html'

    form_class = PelatihanForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        lppbj = akreditasi_lppbj.lppbj

        context['title'] = 'Tambah Pelatihan LPPBJ %s' % (lppbj.singkatan)

        return context

    def form_valid(self, form):
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        data = {
            'akreditasi_lppbj': akreditasi_lppbj,
        }

        form.save(data)

        return redirect(self.get_success_url())

    def get_success_url(self):
        akreditasi_lppbj = get_object_or_404(AkreditasiLppbj, pk=self.kwargs['id_akreditasi'])
        return reverse('lppbj-detail', args=(akreditasi_lppbj.lppbj.pk,))


class PelatihanUpdate(UpdateView):
    model = Pelatihan
    template_name = 'form.html'

    form_class = PelatihanUpdateForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pelatihan = context['pelatihan']
        lppbj = pelatihan.akreditasi_lppbj.lppbj

        context['title'] = 'Update Pelatihan LPPBJ %s' % (lppbj.singkatan)

        return context

    def get_success_url(self):
        pelatihan = get_object_or_404(Pelatihan, pk=self.kwargs['pk'])
        return reverse('lppbj-detail', args=(pelatihan.akreditasi_lppbj.lppbj.pk,))


class PelatihanDelete(DeleteView):
    model = Pelatihan
    
    def get_success_url(self):
        pelatihan = get_object_or_404(Pelatihan, pk=self.kwargs['pk'])
        return reverse('lppbj-detail', args=(pelatihan.akreditasi_lppbj.lppbj.pk,))
