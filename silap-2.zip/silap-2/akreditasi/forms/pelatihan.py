from datetime import datetime
from akreditasi.models import Pelatihan, AkreditasiLppbj
from lppbj.models import Lppbj
from django import forms
from django.shortcuts import get_object_or_404


class PelatihanForm(forms.ModelForm):
    tanggal = forms.DateField(
        widget=forms.SelectDateWidget(years=range(2000, 2050)))

    class Meta:
        model = Pelatihan
        exclude = ('akreditasi_lppbj',)

    def save(self, data):
        obj = super(PelatihanForm, self).save(commit=False)
        obj.akreditasi_lppbj = data['akreditasi_lppbj']

        obj.save()

        return obj


class PelatihanUpdateForm(PelatihanForm):
    class Meta:
        model = Pelatihan
        exclude = ('akreditasi_lppbj',)

    def save(self):
        obj = super(PelatihanForm, self).save()
        obj.save()

        return obj
