from datetime import datetime
from akreditasi.models import AkreditasiLppbj, TipeAkreditasi
from lppbj.models import Lppbj
from django import forms
from django.shortcuts import get_object_or_404


class AkreditasiForm(forms.ModelForm):
    tipe_akreditasi = forms.ModelChoiceField(widget=forms.Select(attrs={
        'class': 'form-control'}),
        queryset=TipeAkreditasi.objects.all()
    )
    nomor_sk = forms.CharField(widget=forms.Textarea(attrs={
        'rows': 2,
        'class': 'form-control'
    }))
    link_sk = forms.CharField(widget=forms.TextInput(attrs={
                'class': 'form-control'
              }), required=False)
    tanggal_berlaku = forms.DateField(widget=forms.SelectDateWidget(
        years=range(2000, 2050)), required=False)
    tanggal_expired = forms.DateField(widget=forms.SelectDateWidget(
        years=range(2000, 2050)), required=False)
    aktif = forms.BooleanField(required=False)

    class Meta:
        model = AkreditasiLppbj
        exclude = ('lppbj',)

    def save(self, data):
        obj = super(AkreditasiForm, self).save(commit=False)
        obj.lppbj = data['lppbj']

        obj.save()

        return obj


class AkreditasiUpdateForm(AkreditasiForm):
    class Meta:
        model = AkreditasiLppbj
        exclude = ('lppbj',)

    def save(self):
        obj = super(AkreditasiForm, self).save()
        obj.save()

        return obj
