from datetime import datetime
from akreditasi.models import Monev, TingkatMonev
from lppbj.models import Lppbj
from django import forms
from django.shortcuts import get_object_or_404
from django.core.validators import MaxValueValidator, MinValueValidator


class MonevForm(forms.ModelForm):
    tanggal = forms.DateField(widget=forms.SelectDateWidget(
                        years=range(2000, 2050)))
    temuan = forms.CharField(widget=forms.Textarea(attrs={
                'rows': 2,
                'class': 'form-control'
             }))
    lokasi = forms.CharField(widget=forms.TextInput(attrs={
                'class': 'form-control'
             }), required=False)
    nilai_lppbj = forms.DecimalField(widget=forms.NumberInput(attrs={
                    'class': 'form-control'
                  }), label='Nilai LPPBJ', max_digits=3, decimal_places=2,
                  initial=0.00, validators=[
                      MinValueValidator(0),
                      MaxValueValidator(1)
                  ], required=False)
    rekom_lppbj = forms.CharField(widget=forms.Textarea(attrs={
                        'rows': 2,
                        'class': 'form-control'
                  }), label='Rekomendasi/Tindak Lanjut LPPBJ', required=False)
    nilai_toc = forms.DecimalField(widget=forms.NumberInput(attrs={
                    'class': 'form-control'
                }), label='Nilai TOC', max_digits=3, decimal_places=2,
                initial=0.00, validators=[
                    MinValueValidator(0),
                    MaxValueValidator(1)
                ], required=False)
    rekom_toc = forms.CharField(widget=forms.Textarea(attrs={
                    'rows': 2,
                    'class': 'form-control'
                }), label='Rekomendasi/Tindak Lanjut TOC', required=False)
    nilai_fasil = forms.DecimalField(widget=forms.NumberInput(attrs={
                    'class': 'form-control'
                  }), label='Nilai Fasil', max_digits=3, decimal_places=2, 
                  initial=0.00, validators=[
                      MinValueValidator(0),
                      MaxValueValidator(1)
                  ], required=False)
    rekom_fasil = forms.CharField(widget=forms.Textarea(attrs={
                        'rows': 2,
                        'class': 'form-control'
                  }), label='Rekomendasi/Tindak Lanjut Fasil', required=False)
    rekom_pusdiklat = forms.CharField(widget=forms.Textarea(attrs={
                            'rows': 2,
                            'class': 'form-control'
                      }), label='Rekomendasi/Tindak Lanjut Pusdiklat',
                      required=False)
    tingkat_monev = forms.ModelChoiceField(widget=forms.Select(attrs={
                        'class': 'form-control'}),
                        queryset=TingkatMonev.objects.all(), required=False
                    )

    class Meta:
        model = Monev
        exclude = ('akreditasi_lppbj',)

    def save(self, data):
        obj = super(MonevForm, self).save(commit=False)
        obj.akreditasi_lppbj = data['akreditasi_lppbj']

        obj.save()

        return obj


class MonevUpdateForm(MonevForm):
    class Meta:
        model = Monev
        exclude = ('akreditasi_lppbj',)

    def save(self):
        obj = super(MonevForm, self).save()
        obj.save()

        return obj
